clear all; close all; clc

set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');

models={'m01a','m01b','m01c','m01d','m01e','m01f','m01g','m01h'};
modellabs={'hyperbolic','exponential','CS','hyperboloid mod.',...
    'quasi-hyperbolic','hyperboloid','double-exp.','control'};

h1=figure('color','white'); hold on; lw=2; box on

ibatch=2;
for imodels=1:length(models)
    model=models{imodels};
    
    pati=['..\data\'];
    pati2=['..\models\' model '\'];
    batchname='MLE_batch2_bounded\';
    
    str='expB_*.mat';
    files=dir([pati str]);
    nfiles=size(files,1);
    
    for i=1:nfiles
        file=files(i).name;
        dat=load([pati file]);
        data=dat.mtx;
        
        ind=data(:,4)==0; data(ind,:)=[];
        vps{i}=dat.vp;
        
        %get beta estimate re-inferred
        str=['*' vps{i} '_A_reward.mat'];
        file2=dir([pati2 batchname str]);
        load([file2.folder '\' file2.name]);
        pars=x.winpar;
                
        %get prediction by model
        mtx=data(:,1:4);
        Y=mtx(:,4); Y(Y==2)=0; %1=immediate, 0=delayed
        
        addpath(pati2)
        [logL, ~, pall,p1]= getLL(pars,mtx);
        rmpath(pati2)
        pimm=unique(data(:,6));
        p=data(:,6);
        m_p=nan(1,length(pimm));
        m_obs=nan(1,length(pimm));
        
        
        T=size(mtx,1);
        for t=1:T
            mut=Y(t);
            muhatt=p1(t);
            
            minval=1e-10;
            maxval=1-minval;
            muhatt(muhatt==1)=maxval;
            muhatt(muhatt<minval)=minval;
            
            if mut==1
                Q(t)=log(mut/muhatt);
            elseif mut==0
                Q(t)=log((1-mut)/(1-muhatt));
            end
            
            clear mut muhatt
        end
        err=2/T*sum(Q);
        
        resd(i,imodels)=err;
        for ip=1:length(pimm)
            ind=p==pimm(ip);
            dev=Q(ind); Ti=length(dev);
            resdcondition(i,ip,imodels)=2/Ti*sum(dev);
        end
        clear Dev
        
        clear x a ind dat* m_*  pimm err
    end
    
    subplot(1,2,1); hold on; box on; grid on
    x=1:length(models);
    cols=[165,0,38;
        215,48,39;
        244,109,67;
        253,174,97;
        254,224,144;
        224,243,248;
        116,173,209;
        49,54,149]/255;
    col=cols(imodels,:);
    resd=resd(:,imodels);
    n=size(resd,1);
    errorbar(imodels,nanmean(resd),nanstd(resd)/sqrt(n),'.','color',col,'LineWidth',lw);
    plot(imodels,nanmean(resd),'-s','color',col,'LineWidth',lw);
    xlim([0 length(x)+1])
    set(gca,'XTick',x,'XTickLabel',modellabs)
    xtickangle(45)
    ylabel('PE (run B)')
    %ylabel('logL')
    
    subplot(1,2,2); hold on; box on; grid on
    jitter=[-.4:.1:.4]*0;
    y=resdcondition(:,:,1);
    x=1:size(y,2);
    
    if ibatch==1
        col='k';
    elseif ibatch==2
        col='b';
    end
    
    for i=imodels %1:length(models)
        col=cols(i,:);
        y=resdcondition(:,:,i);
        ind=isnan(y(:,1)); length(find(ind))
        a=shadedErrorBar(x+jitter(i),nanmean(y),nanstd(y)/sqrt(n),{'.','color',col,'LineWidth',lw});
        a.patch.FaceAlpha=.3;
        l(i)=plot(x+jitter(i),nanmean(y),'color',col,'LineWidth',lw);
    end
    ylabel('PE(j)')
    xlabel('induced frequency')
    set(gca,'XTick',1:9,'XTickLabel',.1:.1:.9)
    xlim([1 9])
    
    PE(:,imodels)=resd;
    clear res* p1 pall pars predy Y y col logL str a
end

set(h1,'Position',[50 50 450 220])

keyboard

