clear all; close all; clc
set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');

pati='..\data\';
pati2='..\models\m01d\MLE_batch2\';

str='expA_*.mat';
files=dir([pati str]);
nfiles=size(files,1);

for i=1:nfiles
    file=files(i).name;
    dat=load([pati file]);
    data=dat.mtx;
    a=data(:,4);
    
    discountA(i)=sum(a==1)/(sum(a==1)+sum(a==2));
    vp=dat.vp;
    vps{i}=vp;
    
    %get beta estimate re-inferred
    str=['*' vp '_A_reward.mat'];
    file2=dir([pati2 str]);
    load([pati2 file2.name]);
    winpar(i,:,2)=x.winpar;
    
    clear dat a data
    file2=['expB__batch2_' vp '.mat'];
    
    dat=load([pati file2]);
    pinduced=dat.pinduced;
    
    data=dat.mtx;
    a=data(:,4);
    
    p_imm=data(:,6);
    p1=unique(p_imm);
    res(i,1:9)=nan;
    for j=1:length(p1)
        pindex=p1(j)*10;
        
        ind=p_imm==p1(j);
        x=data(ind,:);
        truep=pinduced(ind);
        
        a=x(:,4);
        rt=x(:,end);
        res(i,pindex)=sum(a==1)/(sum(a==1)+sum(a==2));
        
        truepred(i,pindex,2)=nanmean(truep);
        clear x a ind
    end
    
end
clear data dat p_imm
truepred=nanmean(truepred(:,:,2));

h1=figure('color','white'); hold on; box on; lw=2;
subplot(1,2,1); hold on; box on; grid on
x=1:9;
y=res;
n=size(y,1);
plot(1:9,.1:.1:.9,'-.k','LineWidth',lw);
plot(x,truepred,'-.r','LineWidth',lw);

a=shadedErrorBar(x,nanmean(y),nanstd(y)/sqrt(n),{'.b','LineWidth',lw});
a.patch.FaceAlpha=.5;
plot(x,nanmean(y),'-b','LineWidth',lw);

ylim([.1 .9]); xlim([1 9]);
set(gca,'XTick',1:9,'XTickLabel',.1:.1:.9,'YTick',.1:.1:.9,'YTickLabel',.1:.1:.9)
xlabel('induced discount freq.');
ylabel('observed discount freq.');

subplot(1,2,2); hold on; box on; grid on
cols=colormap('copper');
for i=1:size(y,1)
    plot(x,y(i,:),'color',cols(i,:),'LineWidth',lw);
end
xlabel('induced discount freq.');
ylabel('observed discount freq.');
set(gca,'XTick',1:9,'XTickLabel',.1:.1:.9,'YTick',.1:.1:.9,'YTickLabel',.1:.1:.9)
xlim([1 9])

set(h1,'Position',[50 50 450 200])

keyboard
