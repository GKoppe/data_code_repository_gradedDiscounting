clear all; close all; clc
pati='..\models\m01d\MLE_batch2\';

set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');

str='*_A_*.mat';
files=dir([pati str]);
nfiles=size(files,1)

for i=1:nfiles
    file=files(i).name;
    file2=[file(1:15) 'B_reward.mat'];
    
    A=load([pati file]);
    B=load([pati file2]);
    
    resA(i,:)=A.x.winpar;
    resB(i,:)=B.x.winpar;
    
    clear data dat
end
parlabs={'beta','kappa','s'};

%% paper fig
%% discount factor correlations
%correlate discount factor at t=30, 90 365
h1=figure('color','white'); hold on; fs=10; box on
parlabs={'90'};
for ipar=1
    ka=resA(:,2)'; kb=resB(:,2)'; lab=parlabs{ipar};
    sa=resA(:,3)'; sb=resB(:,3)';
    
    ind=isnan(sb); ka(ind)=[]; kb(ind)=[]; sb(ind)=[]; sa(ind)=[];
    t=str2num(lab);

    a=(1./(1+ka.*t.^sa));
    b=(1./(1+kb.*t.^sb));
   
    [r,p]=corrcoef(a,b);
    txt=sprintf('r=%2.2f, p=%2.3f',r(1,2),p(1,2));
    disp(txt)
    
    plot(a,b,'ok','MarkerFaceColor','k'); lsline
    xlabel(['A-discount fact.'],'FontSize',fs); 
    ylabel(['B-discount fact.'],'FontSize',fs)
end
set(h1,'Position',[200 200 180 150])
keyboard



