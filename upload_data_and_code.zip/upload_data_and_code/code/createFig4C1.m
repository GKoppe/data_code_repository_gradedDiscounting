clear all; close all; clc
set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');

models={'m01a','m01b','m01c','m01d','m01e','m01f','m01g','m01h'};
modellabs={'hyperbolic','exponential','CS','hyperboloid mod.',...
    'quasi-hyperbolic','hyperboloid','double-exp.','control'};

ibatch=2;
for imodels=1:length(models)
    model=models{imodels};
    
    pati=['..\data\'];
    pati2=['..\models\' model '\'];
    batchname='MLE_batch2_bounded\';
    
    str='expB_*.mat';
    files=dir([pati str]);
    nfiles=size(files,1);
    
    for i=1:nfiles
        file=files(i).name;
        dat=load([pati file]);
        data=dat.mtx;
        
        ind=data(:,4)==0; data(ind,:)=[];
        vps{i}=dat.vp;
        
        %get beta estimate re-inferred
        str=['*' vps{i} '_A_reward.mat'];
        file2=dir([pati2 batchname str]);
        load([file2.folder '\' file2.name]);
        pars=x.winpar;
        
        %get prediction by model
        mtx=data(:,1:4);
        Y=mtx(:,4); Y(Y==2)=0; %1=immediate, 0=delayed
        
        addpath(pati2)
        [logL, ~, pall,p1]= getLL(pars,mtx);
        rmpath(pati2)
        pimm=unique(data(:,6));
        p=data(:,6);
        m_p=nan(1,length(pimm));
        m_obs=nan(1,length(pimm));
        
        %PE across time
        T=size(mtx,1);
        for t=1:T
            mut=Y(t);
            muhatt=p1(t);
            
            minval=1e-10;
            maxval=1-minval;
            muhatt(muhatt==1)=maxval;
            muhatt(muhatt<minval)=minval;
            
            if mut==1
                Q(t)=log(mut/muhatt);
            elseif mut==0
                Q(t)=log((1-mut)/(1-muhatt));
            end
            clear mut muhatt
        end
        err=2/T*sum(Q);
        
        resd(i,imodels)=err;
        clear Dev
    end
    clear x a ind dat* m_*  pimm err
   
    resd=resd(:,imodels); 
    PEindivid(:,imodels)=resd;
    
    clear res* p1 pall pars predy Y y col logL str a
end

clearvars -except PE* mode*

%count individuals
y=PEindivid;
countvar=zeros(1,length(modellabs));
n=size(y,2);
x=1:n;
for i=1:size(y,1)
    yi=y(i,:);
    [val,index]=min(yi);
    epsilon=1e-2;
    tmp=yi-val<epsilon;
    minima=find(tmp);
    
    countvar(minima)=countvar(minima)+1;
end

h1=figure('color','white'); hold on; box on
bar(x,countvar,'FaceColor','k','EdgeColor','k');
set(gca,'XTick',x,'XTickLabel',modellabs)
ylabel('#')
title('run B')
set(h1,'Position',[50 50 250 200])
xtickangle(45)

keyboard
