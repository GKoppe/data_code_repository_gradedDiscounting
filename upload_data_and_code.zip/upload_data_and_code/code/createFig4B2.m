clear all; close all; clc
set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');

models={'m01a','m01b','m01c','m01d','m01e','m01f','m01g','m01h'};
modellabs={'hyperbolic','exponential','CS','hyperboloid mod.',...
    'quasi-hyperbolic','hyperboloid','double-exp.','control'};

h1=figure('color','white'); hold on; lw=2; box on
ibatch=2;
for imodels=1:length(models)
    model=models{imodels};
    
    pati=['..\data\'];
    pati2=['..\models\' model '\'];
    batchname='MLE_batch2_bounded\';
    
    str='expA_*.mat';
    files=dir([pati str]);
    nfiles=size(files,1);
    
    for i=1:nfiles
        file=files(i).name;
        dat=load([pati file]);
        data=dat.mtx;
        
        ind=data(:,4)==0; data(ind,:)=[];
        vps{i}=dat.vp;
        
        %get beta estimate re-inferred
        str=['*' vps{i} '_A_reward.mat'];
        file2=dir([pati2 batchname str]);
        load([file2.folder '\' file2.name]);
        pars=x.winpar;
        
        %get prediction by model
        mtx=data(:,1:4);
        Y=mtx(:,4); Y(Y==2)=0; %1=immediate, 0=delayed
        
        addpath(pati2)
        [logL, ~, pall,p1]= getLL(pars,mtx);
        rmpath(pati2)
        
        k=length(pars);
        AIC=2*k-2*logL;
        resd(i,imodels)=AIC;
        
        clear x a ind dat* m_*  pimm err
    end
    
    subplot(1,2,1); hold on; box on; grid on
    x=1:length(models);
    cols=[165,0,38;
        215,48,39;
        244,109,67;
        253,174,97;
        254,224,144;
        224,243,248;
        116,173,209;
        49,54,149;
        50, 50, 50]/255;
    col=cols(imodels,:);
    resd=resd(:,imodels);
    n=size(resd,1);
    errorbar(imodels,nanmean(resd),nanstd(resd)/sqrt(n),'.','color',col,'LineWidth',lw);
    plot(imodels,nanmean(resd),'-s','color',col,'LineWidth',lw);
    xlim([0 length(x)+1])
    set(gca,'XTick',x,'XTickLabel',modellabs)
    xtickangle(45)
    ylabel('AIC (run A)')
    
    clear res* p1 pall pars predy Y y col logL str a
end

set(h1,'Position',[50 50 450 220])
keyboard

