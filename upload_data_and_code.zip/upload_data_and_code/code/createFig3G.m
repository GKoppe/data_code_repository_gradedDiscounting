clear all; close all; clc
pati=['..\data\'];


set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');

str='expA_*.mat';
files=dir([pati str]);
nfiles=size(files,1)

for i=1:nfiles
    file=files(i).name;
    dat=load([pati file]);
    data=dat.mtx;
    a=data(:,4);
    
    discountA(i)=sum(a==1)/(sum(a==1)+sum(a==2));
    vp=dat.vp;
    %vps{i}=vp;
 
    clear dat a data
    
    file2=['expB__batch2_' vp '.mat'];
    dat=load([pati file2]);
    data=dat.mtx;
    a=data(:,4);
    
    p_imm=data(:,6);
    p1=unique(p_imm);
    for j=1:9
        ind=p_imm==p1(j);
        x=data(ind,:);
        a=x(:,4);
        rt=x(:,end);        
        res(i,j)=sum(a==1)/(sum(a==1)+sum(a==2));
        
        clear x a ind
    end
    clear data dat p_imm
end

%% plot distributions
h1=figure('color','white'); hold on;
lw=2;
y=res;

ss=.1;
bins=[-.05:ss:1.05];
col=colormap('lines');
for i=1:9
    subplot(9,1,i); hold on; grid off; %axis off
    x=y(:,i);
    c='b';
    
    vals=histc(x,bins);
    vals=vals/sum(vals);
    
    stairs(bins,vals,'color',c,'LineWidth',lw)
    alphai=.5;
    for j=1:length(bins)
        xb=bins(j);
        if j<length(bins)
            yb=bins(j+1);
        else
            yb=bins(j)+ss;
        end
        a=area([xb,yb],[vals(j) vals(j)],'FaceColor',c,'EdgeColor','none');
    end
    yl=get(gca,'YLim');
    linecol=[1 0 0];
    line([i*.1 i*.1],yl,'color',linecol,'LineWidth',lw)
    ylabel('relative frequency'); xlim([0 1])
end

xlabel('rel. freq. immediate choice');
xlim([0 1])
set(h1,'Position',[150 150 110 500])


