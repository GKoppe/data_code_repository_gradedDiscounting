%RT analysis 

clear all; close all; clc
set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');

pati=['..\data\'];

str='expB*.mat';
files=dir([pati str]);
nfiles=size(files,1)

for i=1:nfiles
    file=files(i).name;
    dat=load([pati file]);
    data=dat.mtx;
    
    p_imm=data(:,6);
    p1=unique(p_imm);
    for j=1:9
        ind=p_imm==p1(j);
        x=data(ind,:);
        rt=x(:,end);        
        res(i,j)=nanmedian(rt);
        
        clear x a ind
    end
    clear data dat p_imm
end

%sats
Y=res;
n=9;
x=.1:.1:.9;
X=[ones(n,1) x' -(x.^2)'];
b=(X'*X)^(-1)*X'*Y';
b0=b(1,:); b1=b(2,:); b2=b(3,:);
[B,dev,stats] = glmfit(X(:,2:3),mean(Y)');
txt=sprintf('offest T(%d)=%2.2f,p=%2.3f',stats.dfe,stats.t(1),stats.p(1)); disp(txt);
txt=sprintf('linear T(%d)=%2.2f,p=%2.3f',stats.dfe,stats.t(2),stats.p(2)); disp(txt);
txt=sprintf('quadratic T(%d)=%2.2f,p=%2.3f',stats.dfe,stats.t(3),stats.p(3)); disp(txt);


%% plot model predictions against average RT
h1=figure('color','white'); hold on; box on; lw=2;
grid on; fs=10;
x=1:9;
y=res;
n=size(y,1);
shadedErrorBar(x,mean(y),std(y)/sqrt(n),{'.b','LineWidth',lw});

plot(x,mean(y),'-b','LineWidth',lw);
set(gca,'XTick',1:9,'XTickLabel',.1:.1:.9)
xlabel('induced discount freq.','FontSize',fs);
ylabel('RT','FontSize',fs);
xlim([1 9])

set(h1,'Position',[50 50 200 180])

keyboard


