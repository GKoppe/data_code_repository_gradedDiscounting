clear all; close all; clc
pati='..\data\';

set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');

str='expA_*.mat';
files=dir([pati str]);
nfiles=size(files,1);

%choice distribution
for i=1:nfiles
    file=files(i).name;
    dat=load([pati file]);
    data=dat.mtx;
    a=data(:,4);

    resa(i,:)=sum(a==1)/(sum(a==1)+sum(a==2));
    
    clear data dat p_imm
end
%% discount frequency
h1=figure('color','white'); hold on; box on; grid on
lw=2; fs=10;
c='k';
x=resa;

ss=.1;
bins=[0:ss:1];
x(x==0)=.0001; x(x==1)=.9999; %to make sure x=1 is in last bin
vals=histc(x,bins);
vals=vals/sum(vals);

yl=.3;
stairs(bins,vals,'color',c,'LineWidth',lw)
alphai=.5;
for j=1:length(bins)
    xb=bins(j);
    if j<length(bins)
        yb=bins(j+1);
    else
        yb=bins(j)+ss;
    end
    a=area([xb,yb],[vals(j) vals(j)],'FaceColor',c,'EdgeColor','none');
end
ylabel('rel. \# subjects','FontSize',fs); xlabel('rel. freq. immediate','FontSize',fs);
set(gca,'FontSize',fs)
set(h1,'Position',[200 200 200 150])
xlim([0 1])


keyboard
